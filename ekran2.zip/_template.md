# Task: <Screen Name>

Status: NOT READY | IN PROGRESS | DONE

## Goal
<What the screen does, in 1-3 sentences.>

## Required Reading (in this order)
1. `docs/project-overview.md`
2. `docs/conventions/query-screen-conventions.md`
3. `docs/reference/<screen-name>/screen-draft.png`
4. `docs/reference/<screen-name>/sample-response.md`

## Language Rules
- All code in English. Only on-screen texts are Turkish.

| Turkish UI text | Code name |
|---|---|
| <text> | `<name>` |

## Functional Requirements
### Inputs
<Each input, its validation rules, allowed characters, length limits, validation messages.>

### Search
<What is sent to the backend, what happens on success / error / empty.>

### Clear
<What is cleared.>

## Backend Service
- Endpoint: <HTTP method and URL path>
- Request: <how the input values are sent>
- Response: see `docs/reference/<screen-name>/sample-response.md`

## Deliverables
<Files/components expected, route/menu registration if required, tests.>

## Acceptance Checklist
- [ ] UI matches the draft screenshot
- [ ] <screen-specific items>
- [ ] All code is English; only on-screen labels are Turkish

## Prompt for Copilot Agent
```
Read .github/copilot-instructions.md and docs/tasks/<task-file>.md and follow them exactly. Implement only this screen. When finished, list the created/changed files and anything that still needs to be filled in.
```
