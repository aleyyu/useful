# Screens

All three screens are query screens: the user enters a value, presses Search, the backend is called, and the result is shown on the screen. Shared behavior is defined in `docs/conventions/query-screen-conventions.md`.

| # | Screen (Turkish name) | Code name | Task file | Reference folder | Status |
|---|---|---|---|---|---|
| 1 | Şube Sorgulama | `branchQuery` | `docs/tasks/branch-query-screen.md` | `docs/reference/branch-query/` | IN PROGRESS |
| 2 | Merkez Sorgulama | `headOfficeQuery` | `docs/tasks/head-office-query-screen.md` | `docs/reference/head-office-query/` | NOT READY |
| 3 | ESBİS Sorgulama | `esbisQuery` | `docs/tasks/esbis-query-screen.md` | `docs/reference/esbis-query/` | NOT READY |

## Rules
- Screens are implemented one at a time, in the order above.
- Only screens with status `IN PROGRESS` may be implemented, and only when a task asks for it.
- Screens with status `NOT READY` have no requirements yet. Do not create code, routes, menu items, or placeholder files for them.
- Details of screens 2 and 3 (inputs, validation, backend service, result fields) are unknown for now. Do not assume they are the same as screen 1.
- When a screen is completed, its status is changed to `DONE` here.
