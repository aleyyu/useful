# Query Screen Conventions

These rules apply to ALL query screens (Branch Query, Head Office Query, ESBIS Query). Screen-specific rules (which inputs exist, validation rules, backend endpoint, result fields) are defined in each screen's task file and override nothing here unless the task file says so explicitly.

## Screen Structure
- Input area: one or more inputs, followed by the `search` and `clear` buttons.
- Result area: shown only after a successful search.
- Layout, field order, and texts always come from the screen's draft screenshot in `docs/reference/<screen-name>/`.

## Buttons
- `search` (Turkish label: "Sorgula"): validates the inputs, calls the backend service, and shows the response in the matching places of the result area.
- `clear` (Turkish label: "Temizle"): clears all input values, the result area (if any), and any error or validation message. Returns the screen to its initial state.

## Request Handling
- If validation fails, do not call the backend; show the Turkish validation message under the related input.
- Disable the search button and show a loading state while a request is in progress. Do not send duplicate requests.
- Ignore stale responses: if the user presses `clear` or starts a new search while a request is in flight, the old response must not be rendered.
- On error or empty result, show a clear Turkish message and keep the input values.

## Data Handling
- Create response types/interfaces from the sample JSON in `docs/reference/<screen-name>/sample-response.md`.
- Map each JSON field to its place on the screen by comparing the sample JSON with the draft screenshot.
- Handle missing or null fields gracefully (show an empty value placeholder, never crash).
- Format values (dates, amounts, etc.) only if the screenshot shows a specific format.

## Language
- Code in English, on-screen texts in Turkish (see `.github/copilot-instructions.md`).
- Result field labels: take the exact Turkish texts from the screenshot and give them English code names derived from the JSON field names.

## Reuse
- Before creating a component, hook, type, or utility, check whether one already exists in the project (including those created for earlier screens) and reuse it.
- Create something new as shared code only when the task needs it. Follow the project overview for where shared code lives.
- Do not refactor completed screens just to share code, unless the task explicitly asks.

## Tests
- Write unit/component tests if the project already has a testing setup, following its existing pattern.
