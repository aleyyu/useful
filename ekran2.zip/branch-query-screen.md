# Task: Branch Query Screen (Şube Sorgulama)

Status: IN PROGRESS

## Goal
Build the Branch Query screen exactly as shown in the draft screenshot. The user enters a Mersis number and queries the backend; the result is shown on the screen.

## Required Reading (in this order)
1. `docs/project-overview.md` — project structure and conventions (follow strictly)
2. `docs/conventions/query-screen-conventions.md` — shared behavior of all query screens
3. `docs/reference/branch-query/screen-draft.png` — draft UI to reproduce
4. `docs/reference/branch-query/sample-response.md` — sample JSON returned by the backend

## Language Rules
- All code in English (identifiers, files, comments). Only on-screen texts are Turkish.

| Turkish UI text | Code name |
|---|---|
| Şube Sorgulama (screen title, if shown in the draft) | `branchQuery` |
| Mersis Numarası | `mersisNo` |
| Sorgula | `search` |
| Temizle | `clear` |

Result area labels: take the exact Turkish texts from the draft screenshot and give them English code names derived from the JSON field names.

## Functional Requirements

### Input: Mersis Number (`mersisNo`)
- Accepts digits only. Letters, spaces, and special characters must be blocked while typing AND when pasting (strip non-digit characters on change/paste).
- Maximum length is 16 characters.
- A valid Mersis number is exactly 16 digits.
- Use numeric keyboard hints (`inputMode="numeric"`) but do NOT rely on `type="number"` (it drops leading zeros and allows `e`, `+`, `-`).
- If the user tries to search with fewer than 16 digits, do not call the backend; show a Turkish validation message under the input (for example: "Mersis numarası 16 haneli olmalıdır.").

### Button: Search (`search`, "Sorgula")
- Calls the backend service with the entered `mersisNo`.
- Follows the request handling rules in `docs/conventions/query-screen-conventions.md` (loading state, no duplicate requests, stale response protection, error/empty handling).
- On success: render the response in the matching places of the result area, as shown in the draft screenshot.

### Button: Clear (`clear`, "Temizle")
- Clears the input value, the result area (if any), and any error or validation message.

## Backend Service
- Endpoint: `<<FILL IN: HTTP method and URL path>>`
- Request: `<<FILL IN: how mersisNo is sent (query param / path param / body field name)>>`
- Response: see `docs/reference/branch-query/sample-response.md`
- Use the existing API/service layer and base URL/config approach described in `docs/project-overview.md`. If the endpoint above is still not filled in, create the service function with a clearly named constant for the path and mention it in your final summary so it can be completed.

## Deliverables
- Screen/page component, sub-components if needed, service function, types, and Turkish label constants, placed according to `docs/project-overview.md`.
- Route/menu registration only if the project overview says new screens must be registered.
- Unit/component tests if the project already has a testing setup.
- Because two more query screens will follow, if you create reusable pieces (for example a Mersis number input), place them where the project overview says shared code lives. Do NOT create anything for the other screens.

## Acceptance Checklist
- [ ] UI matches the draft screenshot
- [ ] Letters and special characters cannot be typed or pasted into the input
- [ ] Input never exceeds 16 digits; search with fewer than 16 digits shows a validation message and sends no request
- [ ] Search sends the request and fills the result area from the response
- [ ] Loading, error, and empty states work
- [ ] Clear resets the input, the result area, and any messages
- [ ] All code is English; only on-screen labels are Turkish
- [ ] No new libraries or structures outside the project conventions
- [ ] No code created for Head Office Query or ESBIS Query

## Prompt for Copilot Agent
```
Read .github/copilot-instructions.md and docs/tasks/branch-query-screen.md and follow them exactly. Implement only the Branch Query screen using docs/project-overview.md, docs/conventions/query-screen-conventions.md, the screenshot docs/reference/branch-query/screen-draft.png, and the sample response docs/reference/branch-query/sample-response.md. Do not create anything for the other screens. When finished, list the created/changed files and anything that still needs to be filled in (for example the endpoint).
```
