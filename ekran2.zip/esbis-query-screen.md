# Task: ESBIS Query (ESBİS Sorgulama)

Status: NOT READY

> DO NOT IMPLEMENT THIS SCREEN YET. Requirements have not been provided.
> Do not create code, routes, menu items, or placeholder files for it.
> Do not assume it behaves like the Branch Query screen.

## Goal
To be filled in.

## Required Reading (in this order)
1. `docs/project-overview.md`
2. `docs/conventions/query-screen-conventions.md`
3. `docs/reference/esbis-query/screen-draft.png`
4. `docs/reference/esbis-query/sample-response.md`

## Language Rules
- All code in English. Only on-screen texts are Turkish.
- Screen code name: `esbisQuery`

## Functional Requirements
To be filled in (inputs, validation rules, search behavior, clear behavior).

## Backend Service
To be filled in.

## Deliverables
To be filled in.

## Acceptance Checklist
To be filled in. Use `docs/tasks/_template.md` as the structure.
