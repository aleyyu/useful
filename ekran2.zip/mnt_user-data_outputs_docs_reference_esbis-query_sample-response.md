# ESBIS Query (ESBİS Sorgulama) - Sample Backend Response

Not provided yet. Paste the sample JSON below when this screen's task becomes ready.

## Sample JSON

```json
PASTE THE SAMPLE JSON HERE
```
