# Copilot Instructions

## Project Context
- This is a React frontend project. Our team builds all React projects with the same structure.
- The project contains three query screens: Branch Query, Head Office Query, and ESBIS Query. See `docs/screens.md` for the list and the current status of each screen.
- Before writing any code, READ these files in order:
  1. `docs/project-overview.md` — general project structure, folder layout, naming rules, API layer, styling approach. Follow it strictly.
  2. `docs/conventions/query-screen-conventions.md` — shared behavior rules for all query screens.
  3. The task file you were asked to implement in `docs/tasks/`, and every file it references.
- Do not introduce new libraries, folder structures, or patterns that are not already used in the project overview. If something is missing, reuse the closest existing pattern.

## Scope Rules (MANDATORY)
- Implement ONLY the screen named in the task you were given.
- Do NOT implement, scaffold, or create placeholder files for other screens, even if they are listed in `docs/screens.md`.
- A task file whose status is `NOT READY` must not be implemented. If asked to do so, stop and report that the task is not ready.
- Do not modify code of already completed screens unless the task explicitly says so.
- If something is reusable by other screens (shared components, hooks, utilities, types), place it where the project overview says shared code lives. Do not duplicate existing shared code; reuse it.

## Language Rules (MANDATORY)
- ALL code must be in English: file names, folder names, component names, function names, variables, constants, types/interfaces, props, state, comments, commit messages, and test names.
- ONLY user-facing text visible on the screen (labels, button texts, placeholders, validation/error messages) is Turkish.
- Turkish UI text must be kept in a central place (for example a `labels` / `constants` / i18n file, following the project overview) and referenced from components. Do not hardcode Turkish strings inside JSX when the project has a central place for them.
- Example mapping:
  - "Mersis Numarası" -> code name `mersisNo`
  - "Sorgula" -> code name `search`
  - "Temizle" -> code name `clear`
- Make sure Turkish characters (ç, ğ, ı, ö, ş, ü, İ) are saved correctly (UTF-8).

## Implementation Rules
- Reproduce screens exactly as shown in the provided draft screenshot (layout, order of fields, spacing, texts). Do not redesign.
- Keep components small and typed the same way the existing project does (TypeScript or JavaScript as per the project overview).
- Keep API calls in the project's existing service/API layer, not inside UI components.
- Handle loading, success, empty, and error states for every backend call.
- Do not leave unused code, console logs, or TODOs.

## Folder Conventions for Documentation
- `docs/screens.md` — list and status of all screens
- `docs/conventions/` — shared rules for all screens
- `docs/tasks/` — one task file per screen (`_template.md` is the template for new ones)
- `docs/reference/<screen-name>/` — screenshot and sample backend response of that screen
