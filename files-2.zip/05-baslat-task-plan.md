# 05 — Task Plan for mersis-baslat

Work on **one task at a time**, in order. After each task: project compiles, tests pass, then stop and report what was done, what to test, and open questions.

## B1 — Project skeleton
- Spring Boot project (Java 17, Maven) with Web, Validation, Data JPA, Kafka, Oracle driver, Lombok, test dependencies.
- Packages: `config`, `controller`, `dto`, `entity`, `enums`, `exception`, `kafka`, `repository`, `service`, `validation`.
- `application.yml` with datasource, Kafka bootstrap servers, topic names, publish timeout (use placeholders/env variables, no real secrets).
- Done when: application starts (with DB/Kafka config via profile) and a context-load test passes.

## B2 — DTOs and validation
- Request DTOs: `MerkezStartRequest`, `SubeStartRequest`, `EsbisStartRequest`, sharing a base class for `kullaniciKodu` and `kullaniciAdiSoyadi`.
- Annotations per `02-baslat-api-spec.md`. Class-level validator for merkez (exactly one of tckn/vkn), blank treated as missing.
- Response DTO `StartResponse(referansNo)`.
- Done when: unit tests cover every rule, including boundary lengths (32/33, 64/65, 16, 10, 11) and merkez both/neither cases.

## B3 — Reference number generator
- `ReferenceNumberGenerator` interface + UUID v4 implementation.
- Done when: unit test verifies format and uniqueness over many calls.

## B4 — baslat_log persistence
- Enums `ServiceType`, `StartStatus`; entity `BaslatLog`; `BaslatLogRepository`; DDL script from `03-database.md`.
- A `BaslatLogService` with methods to create a `RECEIVED` row, mark `QUEUED`, mark `KAFKA_ERROR`, and log `VALIDATION_ERROR`.
- Done when: repository/service tests pass (H2 in Oracle mode or Testcontainers, whichever is simpler; note the choice in the report).

## B5 — Kafka producer
- `RequestPublisher` interface, Kafka implementation, message class `StartMessage` per `04-kafka-messaging.md`, topic properties class.
- Done when: integration test with EmbeddedKafka verifies key, topic and JSON body for each service; failure path throws `QueuePublishException`.

## B6 — Start services and controllers
- One service per external service (or one generic service with a `ServiceType` parameter — choose the simpler design and keep it DRY).
- Orchestration order exactly as in `02-baslat-api-spec.md` ("Behavior order inside a request").
- 3 controllers (or one controller with 3 mappings) returning HTTP 202.
- Done when: MockMvc tests cover success, validation failure and Kafka failure for each endpoint.

## B7 — Error handling
- `@RestControllerAdvice` producing the error format in `02-baslat-api-spec.md` for validation, malformed JSON and unexpected errors.
- Validation failures must also create the `VALIDATION_ERROR` log row (do this in a way that does not duplicate logic across endpoints).
- Done when: tests verify status codes, bodies, and that no internal details leak.

## B8 — Final check
- Review against all docs, remove unused code, make sure no identity numbers appear in application logs, add a short `README.md` (how to run, config properties, endpoint examples).
- Done when: full test suite passes and the README is accurate.
