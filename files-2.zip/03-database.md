# 03 — Database (Oracle)

Table and column names below are fixed. Schema changes must be delivered as migration/DDL scripts under `src/main/resources/db/` (use Flyway only if it is already in the project; otherwise plain SQL scripts).

## Tables overview
| Table | Written by | Scope now |
|---|---|---|
| `baslat_log` | mersis-baslat | **Implement now** |
| `sonuc_log` | mersis-sonuc | Future |
| `consume_log` | mersis-consumer | Future |
| `merkez`, `sube`, `esbis` | mersis-consumer | Future |

## baslat_log (implement now)
One row per request received by any of the 3 start endpoints.

```sql
CREATE TABLE baslat_log (
    id                   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    referans_no          VARCHAR2(36),
    servis_tipi          VARCHAR2(10)  NOT NULL,   -- MERKEZ | SUBE | ESBIS
    kullanici_kodu       VARCHAR2(32),
    kullanici_adi_soyadi VARCHAR2(64),
    mersis_no            VARCHAR2(16),
    vkn                  VARCHAR2(10),
    tckn                 VARCHAR2(11),
    request_payload      CLOB          NOT NULL,   -- raw request body as received
    durum                VARCHAR2(20)  NOT NULL,   -- RECEIVED | QUEUED | VALIDATION_ERROR | KAFKA_ERROR
    hata_mesaji          VARCHAR2(1000),
    olusturma_zamani     TIMESTAMP(6) WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    guncelleme_zamani    TIMESTAMP(6) WITH TIME ZONE
);

CREATE INDEX idx_baslat_log_referans_no ON baslat_log (referans_no);
```
Rules:
- Typed columns (`kullanici_kodu`, `vkn`, ...) are filled only when the value fits the column; the raw body is always preserved in `request_payload`.
- `referans_no` is NULL for `VALIDATION_ERROR` rows.
- `servis_tipi` and `durum` are Java enums stored as strings (`@Enumerated(EnumType.STRING)`).
- Do not store secrets/headers in the log.

## Future tables (for context only — do NOT create now)
- `sonuc_log`: id, referans_no, servis_tipi, kullanici_kodu, request_payload, durum, olusturma_zamani.
- `consume_log`: id, referans_no, servis_tipi, external_far_id, request_payload, response_status, olusturma_zamani. Records every call the consumer makes to the external service, with `referans_no` and the external far id.
- `merkez`, `sube`, `esbis`: store the external response per identity, keyed by `referans_no`. Their columns will be defined when the external response contract is available.
