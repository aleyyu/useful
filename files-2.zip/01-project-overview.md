# 01 — Project Overview

## Purpose
Provide members with an asynchronous way to query identity information from an external provider. The provider exposes 3 services: **merkez**, **sube**, **esbis**. For each one we expose a **baslat** (start) service and a **sonuc** (result) service.

## Applications
| Application | Responsibility | Status |
|---|---|---|
| `mersis-baslat` | Accept request, validate, log, generate `referansNo`, publish to Kafka, return `referansNo` | **Current scope** |
| `mersis-consumer` | Consume Kafka, call external service, store response (+ `consume_log`) | Future |
| `mersis-sonuc` | Return stored external response by `referansNo` (+ `sonuc_log`) | Future |

## End-to-end flow (same for merkez, sube, esbis)
1. Member calls `POST .../{servis}/baslat` with an identity to query.
2. `mersis-baslat` validates the request and logs it to `baslat_log`.
3. `mersis-baslat` generates a unique `referansNo`, publishes the request to Kafka, and returns `{ "referansNo": "..." }`.
4. `mersis-consumer` reads the message, sends it to the external service, stores the external response in the matching table (`merkez` / `sube` / `esbis`) under the same `referansNo`, and records the call in `consume_log` (with `referansNo` and the external far id).
5. Member calls `POST .../{servis}/sonuc` with the `referansNo`.
6. `mersis-sonuc` logs the call to `sonuc_log`, reads the stored response by `referansNo`, and returns it.

`referansNo` is the correlation key across all tables and both members' calls. Every identity query a member starts is stored under its own `referansNo`, so the system always knows which response belongs to which request.

## Current scope: mersis-baslat
In scope:
- 3 start endpoints (merkez, sube, esbis)
- Request validation
- `baslat_log` persistence
- `referansNo` generation
- Kafka producing (one topic per service)

Out of scope (do not implement): consumer, sonuc endpoints, external service client, `sonuc_log`, `consume_log`, `merkez`/`sube`/`esbis` result tables, authentication.

## Glossary
- **Üye (member)**: the calling client of our API.
- **kullaniciKodu**: member's user code (mandatory, max 32).
- **kullaniciAdiSoyadi**: member's user full name (optional, max 64).
- **mersisNo / vkn / tckn**: identity numbers being queried (16 / 10 / 11 characters).
- **referansNo**: unique reference we return to the member to fetch the result later.
- **external far id**: id returned by the external provider for a request (used later by the consumer).
