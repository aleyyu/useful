# 02 — Baslat API Specification

All request fields are received as **strings**. Content type: `application/json`.

## Endpoints
| Service | Method & Path | Identity input |
|---|---|---|
| merkez | `POST /api/v1/merkez/baslat` | `tckn` **or** `vkn` (exactly one) |
| sube | `POST /api/v1/sube/baslat` | `mersisNo` (required) |
| esbis | `POST /api/v1/esbis/baslat` | `vkn` (required) |

Success response: **HTTP 202 Accepted**
```json
{ "referansNo": "9f1c2b7e-3d0a-4c55-9a53-1b1e0d6f8a21" }
```

## Fields and validation rules

### Common fields (all 3 services)
| Field | Required | Rule |
|---|---|---|
| `kullaniciKodu` | Yes | not blank, max 32 characters |
| `kullaniciAdiSoyadi` | No | if present, max 64 characters |

### Service specific fields
**merkez**
| Field | Rule |
|---|---|
| `tckn` | exactly 11 characters when present |
| `vkn` | exactly 10 characters when present |
| (class-level) | exactly one of `tckn` / `vkn` must be provided. Both missing → error. Both present → error. |

**sube**
| Field | Rule |
|---|---|
| `mersisNo` | required, exactly 16 characters |

**esbis**
| Field | Rule |
|---|---|
| `vkn` | required, exactly 10 characters |

Notes:
- Only length is validated (no digit-only check) unless requirements change. Leave a `// TODO(question)` if you think a format check is needed.
- Blank strings are treated as missing.
- Unknown JSON properties: ignore them (do not fail).
- Do not trim silently: validate the value as received.

## Request examples
merkez (tckn):
```json
{ "kullaniciKodu": "USR001", "kullaniciAdiSoyadi": "Ayşe Yılmaz", "tckn": "12345678901" }
```
merkez (vkn):
```json
{ "kullaniciKodu": "USR001", "vkn": "1234567890" }
```
sube:
```json
{ "kullaniciKodu": "USR001", "mersisNo": "1234567890123456" }
```
esbis:
```json
{ "kullaniciKodu": "USR001", "vkn": "1234567890" }
```

## Error response (validation or server errors)
HTTP 400 for validation errors:
```json
{
  "hataKodu": "VALIDATION_ERROR",
  "mesaj": "Request validation failed",
  "alanlar": [
    { "alan": "kullaniciKodu", "mesaj": "must not be blank" }
  ],
  "zaman": "2026-11-04T10:15:30Z"
}
```
Class-level errors (merkez tckn/vkn rule) use `alan` = `tckn_vkn`.

HTTP 400 also for malformed JSON (`hataKodu`: `MALFORMED_REQUEST`).
HTTP 500 when persistence or Kafka publishing fails (`hataKodu`: `INTERNAL_ERROR`); never leak stack traces or exception messages.

## Behavior order inside a request
1. Bind and validate. On failure: write a `baslat_log` row with `DURUM = VALIDATION_ERROR` (no `referansNo`), return 400.
2. Generate `referansNo`.
3. Write `baslat_log` row with `DURUM = RECEIVED`.
4. Publish to Kafka (see `04-kafka-messaging.md`).
5. On publish success: update row to `DURUM = QUEUED`, return 202 with `referansNo`.
6. On publish failure: update row to `DURUM = KAFKA_ERROR` (with error text), return 500.

## referansNo
- UUID v4 string with dashes (36 characters). Generated in a dedicated `ReferenceNumberGenerator` component (so it can be mocked in tests).
