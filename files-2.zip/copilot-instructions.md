# Copilot Instructions — mersis-baslat

You are building the **mersis-baslat** application. Read this file first, then read the documents in `/docs` before writing any code.

## Project context
We consume 3 external services (**merkez**, **sube**, **esbis**) to query identity information. We expose our own asynchronous API to our members (callers) with a **start (baslat)** and a **result (sonuc)** service per external service (6 services in total).

The system is made of three applications:
- `mersis-baslat` (**this project, current scope**): receives the member's request, validates it, logs it, generates a `referansNo`, publishes the request to Kafka, returns the `referansNo`.
- `mersis-consumer` (future): reads Kafka, calls the external service, stores the response in the DB.
- `mersis-sonuc` (future): returns the stored external response to the member by `referansNo`.

**Only implement `mersis-baslat`. Do not create consumer or sonuc code.**

## Required reading (in this order)
1. `docs/01-project-overview.md` — flow and architecture
2. `docs/02-baslat-api-spec.md` — endpoints, fields, validation rules, error format
3. `docs/03-database.md` — tables and DDL
4. `docs/04-kafka-messaging.md` — topics and message contract
5. `docs/05-baslat-task-plan.md` — ordered tasks; work on ONE task at a time

## Tech stack (assumed — confirm before changing)
- Java 17, Spring Boot 3.x, Maven
- Spring Web, Spring Validation (Jakarta Bean Validation), Spring Data JPA, Spring Kafka
- Oracle database
- JUnit 5, Mockito, Spring Boot Test (+ EmbeddedKafka for integration tests)
- Lombok is allowed for DTOs/entities only

## Coding rules
- Layered structure: `controller` → `service` → `repository` / `kafka producer`. Controllers contain no business logic.
- Constructor injection only. No field injection.
- DTOs are separate from JPA entities. Never expose entities in the API.
- **All request fields are `String`** (including numeric-looking ones such as vkn, tckn, mersisNo). Never convert them to numbers.
- Validation lives in the DTOs via Bean Validation annotations plus custom class-level validators; do not scatter manual `if` checks in services.
- Treat blank strings (`""`, `"   "`) as missing values.
- Error responses follow the format in `docs/02-baslat-api-spec.md`. Use a single `@RestControllerAdvice`.
- Never log full identity numbers (tckn, vkn, mersisNo). Mask them in application logs (e.g., `123*******`). The DB log tables keep the raw values.
- No hard-coded topic names, URLs or limits: use `application.yml` + `@ConfigurationProperties`.
- Use SLF4J for logging, never `System.out`.
- Time values: `Instant`/`OffsetDateTime`, stored as UTC.
- Write unit tests for every validator and service; write a controller test (MockMvc) per endpoint.
- Do not add dependencies that are not needed for the current task.
- Keep each task small: finish it, make sure it compiles and tests pass, then stop and report. Do not start the next task unless asked.

## Naming
- Java classes/fields: English (`StartRequestLog`, `ReferenceNumberGenerator`) is preferred for internal code.
- API field names, DB table names and DB column names are fixed by the docs (Turkish, as written there). Do not rename them.

## When something is unclear
Do not guess silently. Add a `// TODO(question): ...` comment, choose the simplest option, and list the question in your final report.
