# 04 — Kafka Messaging (producer side)

`mersis-baslat` only **produces**. The consumer will be built later against this contract, so do not change it without approval.

## Topics (configurable in `application.yml`)
| Service | Topic |
|---|---|
| merkez | `mersis.merkez.istek` |
| sube | `mersis.sube.istek` |
| esbis | `mersis.esbis.istek` |

Bind them through a `@ConfigurationProperties` class (e.g., `mersis.kafka.topics.merkez`). Topic creation is managed outside the application unless told otherwise.

## Message
- **Key**: `referansNo` (string)
- **Value**: JSON (`JsonSerializer` / `StringSerializer` with Jackson), UTF-8

```json
{
  "referansNo": "202611040000012345",
  "servisTipi": "MERKEZ",
  "kullaniciKodu": "USR001",
  "kullaniciAdiSoyadi": "Ayşe Yılmaz",
  "mersisNo": null,
  "tckn": "12345678901",
  "vkn": null,
  "olusturmaZamani": "2026-11-04T10:15:30Z"
}
```
- `servisTipi`: `MERKEZ` | `SUBE` | `ESBIS`.
- Fields not used by the service are `null` (still present in JSON).
- Do not add the raw request payload or any extra fields.

## Producer behavior
- Producer config: `acks=all`, `enable.idempotence=true`, `retries` with a reasonable delivery timeout (all in `application.yml`).
- The publish is awaited (`KafkaTemplate.send(...).get(timeout)`), because the HTTP response must only be returned after the message is accepted by the broker. The timeout is configurable.
- Wrap failures in a `QueuePublishException`; the service maps it to `KAFKA_ERROR` (see `02-baslat-api-spec.md`).
- Put the publisher behind an interface (`RequestPublisher`) so services can be unit-tested with a mock.
