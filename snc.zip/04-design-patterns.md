# 04 — Design Patterns (shared flow for merkez / sube / esbis)

All 3 sonuc services run the same flow. Only the **service-specific data loading and mapping** differs (which tables, which response fields). Everything else (log row lookup, kurum kodu check, service type resolution, common fields) is identical and exists **once**.

## Patterns
| Pattern | Where | Why |
|---|---|---|
| **Strategy** | `ResultStrategy<R>` — one implementation per service type | Loads that service's tables by `referansNo` and maps them to its response |
| **Registry / Factory** | `ResultStrategyRegistry` | Picks the strategy by `ServiceType` (built from all Spring beans of type `ResultStrategy`) |
| **Single orchestrator (composition)** | `ResultService` | Fixed flow: log lookup → kurum check → type resolution → strategy → common fields |

Do NOT create `MerkezSonucService`/`SubeSonucService`/`EsbisSonucService`, an abstract base service with subclasses, or `if/switch (serviceType)` in `ResultService`.

## Components
```text
controller/SonucController              3 thin mappings; reads kurum kodu header
                                        -> resultService.getResult(endpointType, referansNo, kurumKodu, ResponseClass)
dto/SonucRequest                        referansNo (^\d{18}$)
dto/BaseSonucResponse (abstract)        5 common fields (with setters)
dto/MerkezSonucResponse / SubeSonucResponse / EsbisSonucResponse
enums/ServiceType                       MERKEZ, SUBE, ESBIS; fields: code, pathSegment; fromCode(String)
entity/ReferenceLog                     read-only, maps baslat_log (needed columns only)
entity/...                              read-only entities per table (sube, nace, temsilci, ...)
repository/ReferenceLogRepository       Optional<ReferenceLog> findByReferansNo(String)
repository/...                          findByReferansNo per table (Optional for parent, List for children)
service/ResultStrategy<R extends BaseSonucResponse>
                                        ServiceType supports();
                                        R load(String referansNo);   // never throws for missing rows
service/MerkezResultStrategy, SubeResultStrategy, EsbisResultStrategy
service/ResultStrategyRegistry          get(ServiceType, Class<R>)
service/CommonFieldsMapper              ReferenceLog -> 5 common fields on BaseSonucResponse (written once)
service/ResultService                   the single orchestrator
exception/                              see 02-sonuc-api-spec.md
```

## Orchestrator contract
```java
@Transactional(readOnly = true)
public <R extends BaseSonucResponse> R getResult(ServiceType endpointType, String referansNo,
                                                 String kurumKodu, Class<R> responseType) {
    ReferenceLog log = referenceLogRepository.findByReferansNo(referansNo)
            .orElseThrow(() -> new ReferenceNotFoundException(referansNo));

    if (!Objects.equals(log.getKurumKodu(), kurumKodu)) {
        throw new KurumKoduMismatchException(referansNo);
    }

    ServiceType type = ServiceType.fromCode(log.getServisTipi());      // may throw UnknownServiceTypeException
    if (type != endpointType) {
        throw new ServiceTypeMismatchException(endpointType, type);
    }

    R response = registry.get(type, responseType).load(referansNo);    // no switch/if
    commonFieldsMapper.apply(log, response);
    return response;
}
```
(Illustrative. Keep the order of checks. Keep the generic cast inside the registry.)

## Rules
- `ResultService.getResult(...)` is the **single entry point**, so the owner can later add `sonuc_log` and exception handling around it without touching strategies. Do not add that code now.
- Strategies only read and map the service-specific data. They do not touch the log row, the kurum kodu, or the common fields.
- A strategy loads the parent table row and each child table separately by `referansNo` (no JPA relations). Missing parent → null specific fields; missing children → empty lists.
- Strategies are stateless Spring `@Component`s. Mapping is manual (MapStruct only if already in the project).
- Registry fails fast at startup if a `ServiceType` has no strategy or more than one.
- `ServiceType` codes and path segments live only in the enum.

## Adding a new external service later
1. Add a value (code + path segment) to `ServiceType`.
2. Add a response class extending `BaseSonucResponse`.
3. Add read-only entities/repositories for its tables.
4. Add a `ResultStrategy` implementation.
5. Add one mapping to `SonucController`.
No changes to `ResultService`, the registry, the mapper or existing strategies.

## Tests
- `ResultService` (mocked repository/strategy): success; reference not found; kurum kodu mismatch; unknown service type code; endpoint/service type mismatch; common fields copied from the log row. Verify the strategy is **not** called when a check fails.
- One test per strategy (`@DataJpaTest`): parent + children mapped correctly (sube: `sube`, `nace`, `temsilci`); no rows → null fields / empty lists.
- `ServiceType.fromCode` test, registry test (missing/duplicate).
