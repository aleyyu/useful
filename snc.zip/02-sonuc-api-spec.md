# 02 — Sonuc API Specification

## Endpoints
| Service | Method & Path |
|---|---|
| merkez | `POST /mersis-sorgu/inb/merkez/sonuc` |
| sube | `POST /mersis-sorgu/inb/sube/sonuc` |
| esbis | `POST /mersis-sorgu/inb/esbis/sonuc` |

The path prefix `/mersis-sorgu/inb` and the segments are constants/config, not scattered string literals. `TODO(question)`: the last segment was given as `sonux` in the requirement; `sonuc` is used here, confirm.

Content type: `application/json`. Success: **HTTP 200 OK**.

## Header
| Header | Required | Rule |
|---|---|---|
| kurum kodu header (name: `<<FILL>>`) | Yes | not blank |

Header name comes from configuration (`mersis.kurum-kodu-header`). Use `@RequestHeader` (required) and a not-blank check (`@Validated` controller + `@NotBlank`).

## Request body (same for all 3 services)
```json
{ "referansNo": "202611040000012345" }
```
| Field | Required | Rule |
|---|---|---|
| `referansNo` | Yes | String, not blank, exactly **18 digits** (`^\d{18}$`) |

Keep it a `String` (leading zeros). Unknown JSON properties are ignored. The value is validated as received (no silent trimming).

## Service type codes
The reference log row stores the service type as a **code value**. `ServiceType` enum holds the code and the path segment:

| ServiceType | Path segment | Code stored in log table |
|---|---|---|
| MERKEZ | `merkez` | <<FILL>> |
| SUBE | `sube` | <<FILL>> |
| ESBIS | `esbis` | <<FILL>> |

`ServiceType.fromCode(String)` returns the enum or throws `UnknownServiceTypeException`.

## Response
Flat JSON: 5 common fields + service-specific fields. All strings unless stated otherwise. Null values are serialized as `null`.

| Common field | Source |
|---|---|
| `islemSonucu` | reference log row, column `<<FILL>>` |
| `hataKodu` | reference log row, column `<<FILL>>` |
| `hataKoduAciklamasi` | reference log row, column `<<FILL>>` |
| `durumKodu` | reference log row, column `<<FILL>>` |
| `durumKoduAciklamasi` | reference log row, column `<<FILL>>` |

Assumption (confirm): all 5 common fields come from the log row (not from the service tables) and are returned as stored.

Java model: abstract `BaseSonucResponse` (5 common fields, set by the orchestrator); `MerkezSonucResponse`, `SubeSonucResponse`, `EsbisSonucResponse` extend it with the service-specific fields.

### sube — service-specific response fields
Data comes from three tables linked by `referansNo`: `sube` (parent), `nace` and `temsilci` (children of sube).
- Fields of the `sube` table: <<FILL>> (field, source column, nullable)
- `nace`: JSON array of objects, one per `nace` row: <<FILL>> (fields)
- `temsilci`: JSON array of objects, one per `temsilci` row: <<FILL>> (fields)

(Array structure is the assumed shape; confirm.)

### merkez — service-specific response fields
<<FILL>> (parent table, child tables, fields, array structure)

### esbis — service-specific response fields
<<FILL>> (parent table, child tables, fields, array structure)

## Behavior (fixed order)
1. Bind and validate the body and the kurum kodu header.
2. Find the log row by `referansNo`. None → throw `ReferenceNotFoundException`.
3. Compare the header kurum kodu with the log row's kurum kodu (exact string match). Different → throw `KurumKoduMismatchException`.
4. `ServiceType.fromCode(logRow.servisTipi)` decides which strategy loads the data.
5. If this service type differs from the endpoint's service (e.g., a `sube` reference sent to `/merkez/sonuc`) → throw `ServiceTypeMismatchException`. (Assumption; confirm.)
6. The strategy loads the service-specific data by `referansNo` from its tables and maps it. If no rows exist yet (for example the consumer has not finished, or the external call failed), the strategy returns the response with null specific fields and empty lists; it does **not** throw.
7. The orchestrator copies the 5 common fields from the log row into the response and returns it (HTTP 200).

## Domain exceptions (throw only; do NOT handle)
The project owner will add the exception handling layer. Define these plain runtime exceptions in `exception/` and throw them, nothing more:
- `ReferenceNotFoundException(referansNo)`
- `KurumKoduMismatchException(referansNo)` — never put either kurum kodu value in the message
- `UnknownServiceTypeException(code)`
- `ServiceTypeMismatchException(endpointType, referenceType)`
- `StrategyNotFoundException(ServiceType)` — configuration error

Request/header validation uses standard Spring/Bean Validation mechanisms; do not write custom handlers for their failures.

## Open questions (add `TODO(question)`, do not decide silently)
- Should a kurum kodu mismatch be reported differently from a missing reference? (Different responses reveal that a `referansNo` exists.) The owner decides in the exception handling layer.
- Ordering of child rows (`nace`, `temsilci`) in the response: <<FILL>>.
