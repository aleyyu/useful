# 01 — Project Overview (mersis-sonuc)

## Purpose
Return the stored external-provider response to a member, identified by the `referansNo` the member received from `mersis-baslat`.

## Flow
1. Member calls `POST /mersis-sorgu/inb/{servis}/sonuc` with a `referansNo` in the body and its kurum kodu in an HTTP header.
2. `mersis-sonuc` looks up the `referansNo` in the **reference log table** (`baslat_log`).
3. It compares the kurum kodu stored in the log row with the kurum kodu from the header. A mismatch stops the request.
4. It reads the **service type code** from the log row and resolves the matching service (merkez, sube or esbis).
5. It loads the service-specific data by `referansNo` from that service's tables (e.g., sube: `sube`, `nace`, `temsilci`) and maps it to the response.
6. The 5 common fields (islemSonucu, hataKodu, hataKoduAciklamasi, durumKodu, durumKoduAciklamasi) are taken from the log row and added to the response.
7. HTTP 200 is returned.

`referansNo` is the correlation key: the log row and every result table (parent and child) are linked to each other only by it.

## Scope
In scope:
- 3 result endpoints (merkez, sube, esbis)
- Request validation (`referansNo`) and the kurum kodu header
- Read-only access to the reference log table and the result tables
- Kurum kodu ownership check
- Entity → response mapping
- Strategy-based design shared by the 3 services

Explicitly NOT in scope (the project owner will build these; leave clean extension points, do not implement):
- `sonuc_log` persistence
- Exception handling (error format, `@RestControllerAdvice`, HTTP status mapping for errors)
- Authentication/authorization

## Related applications (do not touch)
| Application | Role |
|---|---|
| `mersis-baslat` | Accepts the query, returns `referansNo`, publishes to Kafka |
| `mersis-consumer` | Calls the external service, writes `merkez`/`sube`/`esbis` tables and `consume_log` |

## Glossary
- **Üye (member)**: caller of our API.
- **referansNo**: unique reference, a string of exactly 18 digits, returned by `mersis-baslat`.
- **kurum kodu**: institution code of the calling member; sent in an HTTP header and stored in the log row when the query was started.
- **Reference log table**: `baslat_log`, one row per `referansNo` (kurum kodu, service type code, result/status columns).
- **islemSonucu / hataKodu / hataKoduAciklamasi / durumKodu / durumKoduAciklamasi**: the 5 fields common to all 3 responses.
