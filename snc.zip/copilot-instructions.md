# Copilot Instructions — mersis-sonuc

You are building the **mersis-sonuc** application. Read this file first, then read the documents in `/docs` before writing any code.

## Project context
We consume 3 external services (**merkez**, **sube**, **esbis**) through an asynchronous API. A member starts a query via `mersis-baslat` and receives a `referansNo`. Later the member calls `mersis-sonuc` with that `referansNo` to get the stored external response.

- `mersis-baslat` (already built, separate application): not your concern.
- `mersis-consumer` (separate application): calls the external service and **writes** the result tables (`merkez`, `sube`, `esbis`). Not your concern.
- `mersis-sonuc` (**this project, current scope**): looks up the `referansNo` in the reference log table, verifies that the caller's kurum kodu (HTTP header) matches the one stored for that `referansNo`, reads the service type from the log row, loads the service-specific data from that service's tables by `referansNo`, maps it to a response, and returns it. **Read-only.**

## Required reading (in this order)
1. `docs/01-project-overview.md` — flow, scope, what is explicitly NOT yours
2. `docs/02-sonuc-api-spec.md` — endpoints, request, response, behavior
3. `docs/03-database-read-model.md` — tables you read (read-only)
4. `docs/04-design-patterns.md` — how the 3 services share one flow (**read before starting any task**)
5. `docs/05-sonuc-task-plan.md` — ordered tasks; work on ONE task at a time

If a document still contains a `<<FILL>>` marker, **stop and ask**. Never invent table names, column names or response fields.

## Out of scope — do NOT implement
- `sonuc_log` table, entity, repository, or any request/response logging to the database (the project owner will add it)
- Exception handling infrastructure: no `@RestControllerAdvice`, no error response format, no HTTP status mapping for errors (the project owner will add it)
- Authentication/authorization, Kafka, calls to the external provider, anything in baslat/consumer
- Creating or changing the result tables (they belong to mersis-consumer)

You may only **throw** the plain domain exceptions listed in `docs/02-sonuc-api-spec.md`. Do not catch and translate them.

## Tech stack (assumed — confirm before changing)
- Java 17, Spring Boot 3.x, Maven
- Spring Web, Spring Validation, Spring Data JPA (read-only usage)
- Oracle database
- JUnit 5, Mockito, Spring Boot Test, `@DataJpaTest`
- Lombok allowed for DTOs/entities only
- No Kafka dependency in this project

## Coding rules
- Layered structure: `controller` → `service` → `repository`. Controllers contain no business logic.
- Constructor injection only.
- Entities are separate from response DTOs. Never expose entities in the API.
- Entities are **read-only**: `@Immutable`, no setters, `spring.jpa.hibernate.ddl-auto=none`. Repositories expose only finder methods (extend `Repository<T, ID>`, not `JpaRepository`).
- All request and response fields are `String` unless `docs/02-sonuc-api-spec.md` says otherwise.
- Request flow order is fixed (see `docs/02-sonuc-api-spec.md`): log row lookup → kurum kodu check → service type from the log row → strategy loads service data. The 5 common response fields come from the **log row**, not from the service tables.
- The 3 sonuc services share ONE flow. Follow `docs/04-design-patterns.md` (Strategy + Registry + single orchestrator). Never create per-service copies of the orchestration code, and never branch on `ServiceType` with `if`/`switch` in the orchestrator.
- Mapping entity → response is written manually inside the strategies (add MapStruct only if it is already in the project).
- Never log identity numbers (tckn, vkn, mersisNo) or the full response body in application logs.
- No hard-coded values (header name, path prefix, service type codes): use `application.yml` + `@ConfigurationProperties` or the `ServiceType` enum.
- SLF4J only, never `System.out`.
- Unit tests for every strategy and the orchestrator; a MockMvc test per endpoint.
- No dependencies that the current task does not need.
- Keep each task small: finish it, make sure it compiles and tests pass, then stop and report. Do not start the next task unless asked.

## Naming
- Internal Java names in English. API field names and DB table/column names are fixed by the docs (Turkish as written there). Do not rename them.

## When something is unclear
Do not guess silently. Add a `// TODO(question): ...` comment, choose the simplest option, and list the question in your final report.
