# 03 — Database (Oracle)

Table and column names below are fixed. Schema changes must be delivered as migration/DDL scripts under `src/main/resources/db/` (use Flyway only if it is already in the project; otherwise plain SQL scripts).

## Tables overview
| Table | Written by | Scope now |
|---|---|---|
| `baslat_log` | mersis-baslat | **Implement now** |
| `sonuc_log` | mersis-sonuc | Future |
| `consume_log` | mersis-consumer | Future |
| `merkez`, `sube`, `esbis` | mersis-consumer | Future |

## baslat_log (implement now)
One row per request received by any of the 3 start endpoints.

```sql
CREATE TABLE baslat_log (
    id                   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    referans_no          VARCHAR2(18),   -- 18 digits, unique
    servis_tipi          VARCHAR2(10)  NOT NULL,   -- service type CODE (values: see ServiceType enum, <<FILL>>)
    kurum_kodu           VARCHAR2(<<FILL>>) NOT NULL, -- from the kurum kodu request header
    kullanici_kodu       VARCHAR2(32),
    kullanici_adi_soyadi VARCHAR2(64),
    mersis_no            VARCHAR2(16),
    vkn                  VARCHAR2(10),
    tckn                 VARCHAR2(11),
    request_payload      CLOB          NOT NULL,   -- raw request body as received
    durum                VARCHAR2(20)  NOT NULL,   -- RECEIVED | QUEUED | VALIDATION_ERROR | KAFKA_ERROR
    hata_mesaji          VARCHAR2(1000),
    olusturma_zamani     TIMESTAMP(6) WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    guncelleme_zamani    TIMESTAMP(6) WITH TIME ZONE
);

CREATE UNIQUE INDEX uq_baslat_log_referans_no ON baslat_log (referans_no);   -- NULLs allowed (validation errors)
```
Rules:
- Typed columns (`kullanici_kodu`, `vkn`, ...) are filled only when the value fits the column; the raw body is always preserved in `request_payload`.
- `referans_no` is NULL for `VALIDATION_ERROR` rows.
- `servis_tipi` stores the **code value** of the `ServiceType` enum (not the enum name); use an `AttributeConverter` (code <-> enum). `durum` is a Java enum stored as a string (`@Enumerated(EnumType.STRING)`).
- This table is also read by `mersis-sonuc` (it looks up `referans_no`, then checks `kurum_kodu` and `servis_tipi`). Columns holding the result info (islem sonucu, hata kodu, durum kodu and their descriptions) are filled later and are owned by the project owner: `<<FILL>>` (do not create them until the names are given).
- Do not store secrets or other headers; the kurum kodu header is the only header stored.

## Future tables (for context only — do NOT create now)
- `sonuc_log`: id, referans_no, servis_tipi, kullanici_kodu, request_payload, durum, olusturma_zamani.
- `consume_log`: id, referans_no, servis_tipi, external_far_id, request_payload, response_status, olusturma_zamani. Records every call the consumer makes to the external service, with `referans_no` and the external far id.
- `merkez`, `sube`, `esbis`: store the external response per identity, keyed by `referans_no`. Their columns will be defined when the external response contract is available.
