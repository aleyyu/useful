# 06 — Design Patterns (shared flow for merkez / sube / esbis)

The 3 start services do the same work. Only these differ:
- the `ServiceType` (and therefore the Kafka topic)
- the identity fields in the request (`tckn`/`vkn`, `mersisNo`, `vkn`) and their validation
- how those fields are mapped to the log row and the Kafka message

Everything else (generate `referansNo`, write `baslat_log`, publish, update status, build the response) is identical and must exist **once**.

## Patterns to use
| Pattern | Where | Why |
|---|---|---|
| **Strategy** | `StartStrategy` — one implementation per service type | Holds the only parts that differ: topic, message mapping, log-field mapping |
| **Registry / Factory** | `StartStrategyRegistry` | Picks the strategy by `ServiceType`; built from all Spring beans of type `StartStrategy` |
| **Template flow (composition, not inheritance)** | `StartService.start(request)` | One orchestrator that runs the fixed step order from `02-baslat-api-spec.md` |

Do NOT use an abstract base service with three subclasses, and do NOT put `if/switch (serviceType)` inside `StartService`. Adding a new external service must not require editing existing strategies or the orchestrator (Open/Closed principle).

## Components
```text
controller/StartController           3 thin mappings -> startService.start(request, kurumKodu)
dto/StartRequest (interface)         ServiceType serviceType(); String getKullaniciKodu(); String getKullaniciAdiSoyadi();
dto/MerkezStartRequest               implements StartRequest (tckn | vkn, class-level validator)
dto/SubeStartRequest                 implements StartRequest (mersisNo)
dto/EsbisStartRequest                implements StartRequest (vkn)
enums/ServiceType                    MERKEZ, SUBE, ESBIS
service/StartStrategy<R>             ServiceType supports();
                                     StartMessage toMessage(R request, String referansNo, Instant now);
                                     BaslatLogFields toLogFields(R request);
service/MerkezStartStrategy          implements StartStrategy<MerkezStartRequest>
service/SubeStartStrategy            implements StartStrategy<SubeStartRequest>
service/EsbisStartStrategy           implements StartStrategy<EsbisStartRequest>
service/StartStrategyRegistry        Map<ServiceType, StartStrategy<?>>; get(ServiceType)
service/StartService                 the single orchestrator
kafka/RequestPublisher               publish(ServiceType, StartMessage)  -> topic resolved from properties by ServiceType
```

## Orchestrator contract
```java
public <R extends StartRequest> StartResponse start(R request, String kurumKodu) {
    StartStrategy<R> strategy = registry.get(request.serviceType());   // no switch/if
    String referansNo = referenceNumberGenerator.generate();
    BaslatLog log = baslatLogService.received(referansNo, kurumKodu, request.serviceType(), strategy.toLogFields(request), rawPayload);
    try {
        publisher.publish(request.serviceType(), strategy.toMessage(request, referansNo, clock.instant()));
        baslatLogService.queued(log);
        return new StartResponse(referansNo);
    } catch (QueuePublishException e) {
        baslatLogService.kafkaError(log, e);
        throw e;
    }
}
```
(Illustrative. Keep the behavior order from `02-baslat-api-spec.md`; handle the generic cast in the registry, not in callers.)

## Rules
- Bean Validation stays on each request DTO (different rules per type). Strategies do **not** validate.
- Strategies are stateless Spring `@Component`s with no I/O (pure mapping), so they are trivial to unit test.
- Topic names come from the properties class keyed by `ServiceType`, never from strategies.
- Inject `Clock` instead of calling `Instant.now()` directly (testability).
- The kurum kodu is read from the header in the controller and passed to `StartService`; it is not part of the request body DTOs or the Kafka message.
- `StartStrategyRegistry` must fail fast at startup if a `ServiceType` has no strategy or has more than one.

## Adding a new external service later (checklist)
1. Add a value to `ServiceType`.
2. Add a request DTO implementing `StartRequest` with its validations.
3. Add a `StartStrategy` implementation.
4. Add its topic to `application.yml` / the topics properties class.
5. Add one mapping to `StartController`.
No changes to `StartService`, the registry, or existing strategies.

## Tests
- One unit test per strategy: mapping to `StartMessage` and `BaslatLogFields` (unused fields must be `null`).
- Registry test: missing and duplicate strategy detection.
- `StartService` test with mocked strategy/publisher/log service: success path and publish-failure path.
