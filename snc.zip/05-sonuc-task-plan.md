# 05 — Task Plan for mersis-sonuc

Work on **one task at a time**, in order. After each task: project compiles, tests pass, then stop and report what was done, what to test, and open questions.

**Before S2/S3:** the `<<FILL>>` markers that concern the work of the task (service type codes, header name, log table columns, service tables/fields) must be filled in `02-sonuc-api-spec.md` and `03-database-read-model.md`. If not, stop and ask.

## S1 — Project skeleton
- Spring Boot project (Java 17, Maven): Web, Validation, Data JPA, Oracle driver, Lombok, test dependencies. No Kafka.
- Packages: `config`, `controller`, `dto`, `entity`, `enums`, `exception`, `repository`, `service`.
- `application.yml`: datasource (placeholders/env variables), `spring.jpa.hibernate.ddl-auto=none`, `mersis.kurum-kodu-header`, base path `/mersis-sorgu/inb`.
- Done when: context-load test passes.

## S2 — DTOs, enum and validation
- `SonucRequest` (`referansNo`: not blank, `^\d{18}$`).
- `ServiceType` enum with `code`, `pathSegment`, `fromCode` (throws `UnknownServiceTypeException`).
- `BaseSonucResponse` (5 common fields) and the 3 response classes.
- Domain exceptions listed in `02-sonuc-api-spec.md` (plain runtime exceptions, no handlers).
- Done when: tests cover referansNo (null, blank, 17, 18, 19 chars, letters, leading zeros kept), `fromCode` (known/unknown), and flat JSON serialization with nulls.

## S3 — Read-only entities and repositories
- `ReferenceLog` entity + repository (only the needed columns).
- Entities/repositories of the service tables (sube: `sube`, `nace`, `temsilci`), no JPA relations. One service at a time as the docs get filled.
- Done when: `@DataJpaTest` finds the log row and the table rows by `referansNo`; unknown `referansNo` returns empty.

## S4 — Strategies
- `ResultStrategy<R>`, `SubeResultStrategy` first, then `MerkezResultStrategy`, `EsbisResultStrategy` when their docs are filled.
- Done when: strategy tests verify parent + children mapping and the "no rows" case (null fields, empty lists).

## S5 — Registry, common mapper and orchestrator
- `ResultStrategyRegistry` (fail fast), `CommonFieldsMapper`, `ResultService.getResult(...)` exactly as in `04-design-patterns.md`.
- Done when: all `ResultService`, registry and mapper tests described there pass.

## S6 — Controller
- `SonucController` with the 3 mappings under `/mersis-sorgu/inb/{servis}/sonuc`, `@Valid` body, required not-blank kurum kodu header (configurable name), HTTP 200.
- Done when: MockMvc tests cover, per endpoint: success (full JSON), invalid `referansNo`, missing/blank header (standard Spring mechanism), and propagation of the domain exceptions (asserted as thrown; handling is out of scope).

## S7 — Final check
- Review against all docs: no per-service orchestration copies, no `sonuc_log`, no exception handler, no identity numbers or kurum kodu in application logs, no DDL, no JPA relations.
- Short `README.md`: how to run, config properties, endpoint examples.
- Done when: full test suite passes and the README is accurate.
