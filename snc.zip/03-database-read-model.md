# 03 — Database Read Model (Oracle, read-only)

`mersis-sonuc` only **reads** the tables below. They are written by `mersis-baslat` (log row) and `mersis-consumer` (result tables and result columns of the log row).

Rules:
- Do not create, alter or drop these tables. No DDL, `spring.jpa.hibernate.ddl-auto=none`.
- Map them with `@Entity` + `@Immutable` + `@Table(name = "...")`; no setters.
- **No JPA relationships** (`@OneToMany`/`@ManyToOne`) between parent and child tables. They are linked only by the `referans_no` column; each table gets its own entity and its own repository with a finder by `referans_no`.
- Repositories extend `Repository<T, ID>` (not `JpaRepository`) and expose finders only.
- Do not read `consume_log` or `sonuc_log`.

## Reference log table: `baslat_log`
One row per `referansNo`. Used for: existence check, kurum kodu check, service type, common response fields.

| Column | Type | Used for |
|---|---|---|
| `referans_no` | VARCHAR2(18) | lookup key (unique) |
| `kurum_kodu` | VARCHAR2(<<FILL>>) | compared with the header |
| `servis_tipi` | VARCHAR2(10) | service type **code** (see `02-sonuc-api-spec.md`) |
| <<FILL>> | | `islemSonucu` |
| <<FILL>> | | `hataKodu` |
| <<FILL>> | | `hataKoduAciklamasi` |
| <<FILL>> | | `durumKodu` |
| <<FILL>> | | `durumKoduAciklamasi` |

Map only the columns listed here; ignore the others (e.g., `request_payload`, `durum`, `hata_mesaji`) — do not map the CLOB.

## Result tables (written by mersis-consumer)
Every table has a `referans_no VARCHAR2(18)` column holding the member's `referansNo`.

### sube service
| Table | Role | Rows per `referans_no` |
|---|---|---|
| `sube` | parent | <<FILL>> (expected: one) |
| `nace` | child of sube | many |
| `temsilci` | child of sube | many |

Columns of each table and their response mapping: <<FILL>> (column, type, nullable, response field).

### merkez service
Tables, roles, cardinalities and columns: <<FILL>>

### esbis service
Tables, roles, cardinalities and columns: <<FILL>>

## Test data
Tests use a schema created by the test setup only (H2 in Oracle mode or Testcontainers; note the choice in the report). It must mirror the tables above and must never be shipped as a production migration.
