# Code Review Standards

This document defines the team's code review standards. The `code-reviewer` agent
checks every change against these rules. Each rule has a stable ID, a severity, and
a short description. Rule IDs are used in review reports.

> NOTE: This is a sample. The examples assume a Java / Spring Boot codebase.
> Replace, remove, or add rules so that they match the team's actual standards.

## Severity levels

- **Critical**: Must be fixed before committing (bugs, security issues, data loss, broken contracts).
- **Major**: Should be fixed before committing unless there is a documented reason.
- **Minor**: Improvement suggestion. Does not block committing.

---

## 1. Architecture and Layering (ARCH)

| ID | Severity | Rule |
|----|----------|------|
| ARCH-01 | Critical | Controllers must not access repositories directly. Use the service layer. |
| ARCH-02 | Major | Business logic belongs in services, not in controllers, entities, or mappers. |
| ARCH-03 | Major | Entities must not be exposed in API responses. Use DTOs. |
| ARCH-04 | Major | No circular dependencies between packages or modules. |
| ARCH-05 | Minor | Prefer constructor injection over field injection. |

## 2. Naming and Readability (READ)

| ID | Severity | Rule |
|----|----------|------|
| READ-01 | Major | Class, method, and variable names must be descriptive and follow Java conventions (`PascalCase` for classes, `camelCase` for methods and variables, `UPPER_SNAKE_CASE` for constants). |
| READ-02 | Major | Methods should do one thing and generally stay under 40 lines. |
| READ-03 | Minor | Avoid deep nesting (more than 3 levels). Use early returns or extract methods. |
| READ-04 | Minor | No commented-out code. Remove it. |
| READ-05 | Minor | No magic numbers or magic strings. Use named constants or enums. |

## 3. Error Handling (ERR)

| ID | Severity | Rule |
|----|----------|------|
| ERR-01 | Critical | Never swallow exceptions (empty `catch` blocks). Handle, log with context, or rethrow. |
| ERR-02 | Major | Do not catch `Exception` or `Throwable` unless at an application boundary. |
| ERR-03 | Major | Use the project's custom exception types for business errors. Do not throw bare `RuntimeException`. |
| ERR-04 | Major | Do not use exceptions for normal control flow. |
| ERR-05 | Minor | Exception messages must contain enough context to diagnose the problem (ids, states). |

## 4. Null Safety and Data Handling (NULL)

| ID | Severity | Rule |
|----|----------|------|
| NULL-01 | Critical | Possible `null` values must be handled before dereferencing. |
| NULL-02 | Major | Do not return `null` from methods that return collections. Return empty collections. |
| NULL-03 | Major | Use `Optional` only for return values, not for fields or method parameters. |
| NULL-04 | Minor | Validate public method inputs, using `Objects.requireNonNull` or bean validation. |

## 5. Persistence and Transactions (DB)

| ID | Severity | Rule |
|----|----------|------|
| DB-01 | Critical | Transaction boundaries (`@Transactional`) belong in the service layer, not in controllers or repositories. |
| DB-02 | Critical | No string concatenation in queries. Use parameterized queries. |
| DB-03 | Major | Avoid N+1 query patterns. Use fetch joins, entity graphs, or batch fetching. |
| DB-04 | Major | Do not load entire tables into memory. Use pagination for unbounded results. |
| DB-05 | Major | Schema changes must be done through migration scripts, never manually. |
| DB-06 | Minor | Read-only operations should be marked `@Transactional(readOnly = true)`. |

## 6. Security (SEC)

| ID | Severity | Rule |
|----|----------|------|
| SEC-01 | Critical | No secrets, passwords, tokens, or keys in source code or committed config files. |
| SEC-02 | Critical | All external input must be validated and sanitized. |
| SEC-03 | Critical | Endpoints must have explicit authorization checks unless they are intentionally public. |
| SEC-04 | Critical | Never log sensitive data (passwords, tokens, personal data, card numbers). |
| SEC-05 | Major | Do not disable TLS verification or CSRF protection without a documented reason. |
| SEC-06 | Major | Use well-known libraries for cryptography and hashing. No custom implementations. |

## 7. Logging (LOG)

| ID | Severity | Rule |
|----|----------|------|
| LOG-01 | Major | Use the project's logging framework (SLF4J). No `System.out.println` or `printStackTrace`. |
| LOG-02 | Major | Use the correct log level (`ERROR` for failures, `WARN` for recoverable issues, `INFO` for business events, `DEBUG` for diagnostics). |
| LOG-03 | Minor | Use parameterized log messages (`log.info("Order {} created", id)`), not string concatenation. |
| LOG-04 | Minor | Do not log the same exception at multiple layers. |

## 8. Concurrency (CONC)

| ID | Severity | Rule |
|----|----------|------|
| CONC-01 | Critical | Shared mutable state must be protected (synchronization, concurrent collections, or immutability). |
| CONC-02 | Major | Do not create raw threads. Use managed executors. |
| CONC-03 | Major | Singleton beans (services, components) must be stateless or thread-safe. |
| CONC-04 | Minor | Prefer immutable objects where possible. |

## 9. API Design (API)

| ID | Severity | Rule |
|----|----------|------|
| API-01 | Critical | Do not introduce breaking changes to existing public APIs without versioning. |
| API-02 | Major | Use proper HTTP methods and status codes. |
| API-03 | Major | Request bodies must be validated (`@Valid`) and return clear validation errors. |
| API-04 | Minor | Endpoint and field naming must be consistent with existing APIs. |

## 10. Testing (TEST)

| ID | Severity | Rule |
|----|----------|------|
| TEST-01 | Major | New or changed business logic must have unit tests. |
| TEST-02 | Major | Bug fixes must include a test that reproduces the bug. |
| TEST-03 | Major | Tests must be deterministic. No dependency on time, randomness, ordering, or external services without control. |
| TEST-04 | Minor | Test names must describe behavior (`shouldRejectOrderWhenStockIsZero`). |
| TEST-05 | Minor | Tests must contain meaningful assertions. No tests without assertions. |

## 11. Performance (PERF)

| ID | Severity | Rule |
|----|----------|------|
| PERF-01 | Major | No blocking or remote calls inside loops when a batch alternative exists. |
| PERF-02 | Major | Avoid unnecessary object creation and repeated expensive computations in hot paths. |
| PERF-03 | Minor | Use `StringBuilder` for string building in loops. |

## 12. Dependencies and Configuration (CFG)

| ID | Severity | Rule |
|----|----------|------|
| CFG-01 | Major | New dependencies must be justified and use approved, maintained libraries. |
| CFG-02 | Major | Configuration values must come from configuration files or environment, not hardcoded. |
| CFG-03 | Minor | Remove unused imports, variables, and dependencies. |

## 13. Documentation (DOC)

| ID | Severity | Rule |
|----|----------|------|
| DOC-01 | Minor | Public APIs and non-obvious logic must have clear Javadoc or comments explaining why, not what. |
| DOC-02 | Minor | Update README or relevant docs when behavior, setup, or configuration changes. |
