# Reference docs (offline)

Official documentation pages copied here by a human, because the network may block documentation sites. Trust these files over memory. Read only the file relevant to your task. If a topic you need is not here, ask the human to add it instead of guessing or trying to browse the web.

All pages come from the IntelliJ Platform Plugin SDK documentation (https://plugins.jetbrains.com/docs/intellij/).

| File | Source page (path after the base URL) | Used by | Priority |
|---|---|---|---|
| `gradle-plugin.md` | `tools-intellij-platform-gradle-plugin.html` + `configuring-gradle.html` (paste both into one file) | T0.5.6 (build target, local IDE) | **Needed now** |
| `threading-model.md` | `threading-model.html` | Phase 2 (all background work) | Before Phase 2 |
| `background-processes.md` | `background-processes.html` | Phase 2 (progress, cancellation) | Before Phase 2 |
| `plugin-configuration-file.md` | `plugin-configuration-file.html` | any `plugin.xml` change | Optional |
| `notifications.md` | `notification-balloons.html` | T0.5.4 (already done; only if notifications are changed) | Optional |
| `tool-windows.md` | `tool-windows.html` | T0.5.1 (already done; only if the tool window is changed) | Optional |
| the three Copilot Java SDK files (getting started, documentation, advanced usage) | GitHub Copilot Java SDK documentation pages, pasted by the human | Phase 1 (T1.1b onward) | **Needed now** |

Commit checks (`CheckinHandlerFactory`, `CommitCheck`, `CheckinHandler`): there is no dedicated official documentation page for these. Verify them with `javap` against the local IDE jars (see "Documentation access" in `AGENTS.md`) instead of a reference file.
