# Reference docs (offline)

Official documentation pages copied here by a human, because the network may block documentation sites. Trust these files over memory. Read only the file relevant to your task.

Expected files (add the ones that are missing; file names are suggestions):

| File | Topic | Used by |
|---|---|---|
| `notifications.md` | Notifications API (notification groups, balloons, actions/links) | T0.5.4 |
| `tool-windows.md` | Registering and building tool windows | T0.5.1 - T0.5.3 |
| `commit-checks.md` | Commit checks / commit handlers (`CheckinHandlerFactory`, `CommitCheck`) | T0.2, T0.5.5, Phase 2 |
| `threading-rules.md` | Threading rules (EDT, read/write actions) | all tasks |
| `background-processes.md` | Background tasks and progress | Phase 2 |
| `plugin-configuration-file.md` | `plugin.xml` elements and extension points | all tasks |
| `gradle-plugin.md` | IntelliJ Platform Gradle Plugin: platform dependencies (unified IDEA 2025.3, local IDE), `verifyPlugin` | T0.5.6 |

If a topic you need is not here, ask the human to add it instead of guessing.
