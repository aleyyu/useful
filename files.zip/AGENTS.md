# AGENTS.md — AI Commit Review Plugin (IntelliJ)

Persistent rules for every AI agent (Copilot agent mode, Copilot CLI, etc.) working in this repo. Follow them in every session.

## Project
An IntelliJ IDEA plugin, user-facing name **"AI Reviewer"**, that before a developer commits takes the changes about to be committed (the diff) and:
1. Checks them against the team's coding standards defined in an md file,
2. Finds error-prone, critical points,
3. Reports findings as warnings (must fix) and suggestions (could improve): a balloon notification shows the counts with a "Review code analysis" link, and a dedicated tool window at the bottom of the IDE lists the details.
AI calls use the company's GitHub Copilot account credits.

Two core constraints: **low token consumption** and **never slowing down the IDE**.

## Naming (canonical)
- The user-facing name is **"AI Reviewer"**: tool window (id and title), notification group (id and display name), and balloon title.
- Do not use "AI Review" (without "er") anywhere in code, resources, `plugin.xml`, or docs.

## Read first
- `docs/spec.md` — what to build, acceptance criteria, budgets
- `docs/architecture.md` — architecture decisions
- `docs/tasks.md` — task list (your assigned task comes from here)

## Technical environment
- Target IDE: IntelliJ IDEA 2025.3.x (build 253). Since 2025.3 there is a single unified distribution; do not target the old Community 2024.2.x line. Use the unified-distribution dependency in Gradle (check `docs/reference/` for the correct form).
- Build: IntelliJ Platform Gradle Plugin 2.x (2.10.4 or newer). Start with the version the template ships; do not upgrade it on your own.
- JDK: IntelliJ Platform 2025.3 is Java 21 level. This project **builds and runs on JDK 21**. (The team's general standard is Java 17; this project is an exception.)
- Language: **Java**. Do not write Kotlin application code. Note: Gradle build files (`*.gradle.kts` / `*.gradle`) may stay as they are; they are build scripts, not application code.
- Commands:
  - Build and test: `./gradlew build`
  - Tests only: `./gradlew test`
  - Launch sandbox IDE for manual testing: `./gradlew runIde`
  - Compatibility check: `./gradlew verifyPlugin` (needs network; if the network blocks it, say so in your summary instead of failing the task)
- Building against a locally installed IDE (when downloads are blocked): set the environment variable `COMMIT_REVIEWER_IDE` to the IDE installation folder. Keep this option working and documented here.

## Documentation access (the network may be restricted)
External documentation sites and downloads may be blocked. **Do not try to browse web docs or fetch URLs** — it wastes time and tokens. To verify an IntelliJ Platform or Gradle plugin API:
1. Read the relevant file in `docs/reference/` (only the one you need for the task; do not read them all).
2. Inspect the real classes with `javap` against the jars in the local IDE's `lib` folder (find the jar that contains the class), for example: `javap -classpath <jar> <fully.qualified.ClassName>`.
3. If still unsure, ask the human. Do not guess or invent APIs.

## Working rules
- Do **only the single task** you are given. Do not go beyond `docs/spec.md` or add extra features.
- **Do not invent APIs.** See "Documentation access" above.
- Do not add unnecessary dependencies. If a new dependency is needed, explain why and ask for approval.
- When the task is done, run `./gradlew build`. Summarize in this format: changed files, what works / what does not, open questions.
- No broad refactors. Make small, reversible changes.
- Do not read the whole repo unless needed. Open only files relevant to the task (your own token usage also consumes credits).
- If the spec contradicts itself or is unclear, ask or state your interpretation in the summary; do not silently pick one.

## Non-negotiable architecture rules
1. **Never block the UI thread (EDT).** Network calls, AI calls, process execution, and heavy diff processing run on a background thread.
2. **Fail-open:** an AI error, timeout, or credit/limit problem must never block a commit. Show the user a short notice and allow the commit.
3. **The AI call is single-shot:** no tool use, no agent loop; one prompt and a structured (JSON) response. Details in `docs/architecture.md`.
4. Source code and tokens/credentials are **never written to logs**.
5. Local (non-AI) checks run first; the AI is called only when needed and with small input.
6. **Findings are shown in two places, like the IDE's Problems notifications:** a balloon notification with the warning and suggestion counts and a clickable "Review code analysis" link below it, and the details in the "AI Reviewer" tool window opened from that link. The tool window is never opened automatically. Findings are never shown in modal dialogs. The findings data model (`Finding`, `Severity`) is independent of the UI.

## Testing
- Write unit tests (JUnit) for every class with logic. For IDE-dependent behavior, use the IntelliJ Platform test infrastructure (`BasePlatformTestCase`, etc.).
- AI-call tests **never hit the real service**; use a fake implementation behind an interface.
