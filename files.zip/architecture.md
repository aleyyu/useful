# Architecture — AI Commit Review Plugin

Status: DRAFT v0.4. Implemented so far: commit hook (Phase 0), notification and tool window with fake data (Phase 0.5, being finalized).

User-facing plugin name: **"AI Reviewer"**.

## 1. Overall flow (target)
```
Commit button
   -> Commit hook (IntelliJ commit check)
   -> [background thread]
        1. Change collector: only the diff to be committed
        2. Filter: drop generated/lock/binary/very large files
        3. Local rules: deterministic checks without AI
        4. Cache: was this diff hash already asked?
        5. Rule selector: relevant rules from the standards md
        6. Prompt builder: diff + relevant rules + output schema
        7. AI client (interface) -> Copilot (single-shot, no tools)
        8. Output parser: JSON -> list of findings
   -> UI: show a balloon notification with the warning and suggestion counts and a "Review code analysis" link; the link opens the "AI Reviewer" tool window with the details
   -> Commit proceeds (fail-open)
```
Until Phase 2, steps 1-8 are replaced by a single provider of fake findings.

## 2. Components (suggested packages)
- `hook` — IntelliJ commit integration (plugin.xml registration, handler)
- `collect` — change collection and filtering
- `local` — local rule engine
- `standards` — md reading, splitting, rule selection
- `prompt` — prompt building
- `ai` — `ReviewClient` interface + Copilot implementation + fake for tests
- `model` — `Finding`, `Severity`
- `ui` — two parts: (1) a notifier that shows the balloon (title "AI Reviewer", "<N> warnings, <M> suggestions" line, clickable "Review code analysis" link) using a dedicated notification group; (2) the "AI Reviewer" tool window (bottom-anchored, tree/list of findings grouped as Warnings/Suggestions, navigation to file and line). The link in the balloon opens the tool window. The `ui` package only reads a list of `Finding` objects and never calls the AI itself.
- `settings` — user settings (budget, on/off, model)

The `ai` package must sit behind an interface: the Copilot access path may change in Phase 1, and the rest of the code must not be affected.

## 3. Threading rules
- The commit hook is called on the EDT. Only very fast work is done there.
- Diff collection, the AI call, and parsing run in the background (using IntelliJ's cancellable background task/progress mechanism).
- If the user cancels or a timeout occurs, the work stops and the commit is released.
- UI updates (balloon, tool window content) happen on the EDT.

## 4. Token-saving layers (in priority order)
1. Local rules run before the AI.
2. Filter: unnecessary files are never sent.
3. Only changed hunks + a few context lines are sent.
4. Only relevant rules from the standards are sent.
5. Cache: no repeat request for the same diff.
6. Single-shot, no tools, short structured output, max output limit.
7. Daily/per-user request limit, ability to disable in settings.
8. Cheaper model option.

## 5. Error and security principles
- Fail-open: any AI-side error releases the commit.
- Source code, tokens, and prompt contents are not written to logs.
- The plugin does not store credentials itself; Copilot's own session is used (to be confirmed in Phase 1).

## 6. Development environment notes
- Target platform: IntelliJ IDEA 2025.3 (unified distribution, build 253), JDK 21.
- Copilot access: on the developer machine the SDK cannot start the Copilot CLI itself. The CLI runs as a local server (loopback only) and the SDK connects to it with `cliUrl` (currently `localhost:4321`). Who starts the server (developer or plugin) is decided in Phase 1.
- The network may block downloads and documentation sites. The build can use a locally installed IDE via `COMMIT_REVIEWER_IDE`. Agents verify APIs from `docs/reference/` and with `javap` on the local IDE jars, never from the web.

## 7. Decision log
| Date | Decision | Reason |
|---|---|---|
| — | Language: Java | Team preference |
| — | AI call is single-shot, no tools | Token control |
| — | Fail-open | Never block the commit flow |
| — | Findings UX works like the IDE's Problems: a balloon shows "<N> warnings, <M> suggestions" with a "Review code analysis" link; the details are in a bottom tool window opened from that link; the tool window never opens automatically | Familiar behavior; short notice without interrupting the developer, details kept readable |
| — | User-facing name is "AI Reviewer" everywhere | Consistency; earlier docs mixed "AI Review" and "AI Reviewer" |
| — | Default build target is IDEA 2025.3; local-IDE build option via `COMMIT_REVIEWER_IDE` | Downloads can be blocked; template default (2024.2.5) was outdated |
| — | Agents use offline reference docs and `javap`, not web docs | Blocked network made web lookups slow and wasteful |
